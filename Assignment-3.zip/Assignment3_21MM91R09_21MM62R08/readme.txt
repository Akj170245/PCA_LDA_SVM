Required packages are mentioned in requirements.txt
If packages are not installed run the below command line then run the KNN.py file
  pip install -r requirements.txt
  python KNN.py
